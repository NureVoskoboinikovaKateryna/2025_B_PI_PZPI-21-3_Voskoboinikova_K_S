export class LoginData {
  Email: string = ""
  Password: string = ""
}
