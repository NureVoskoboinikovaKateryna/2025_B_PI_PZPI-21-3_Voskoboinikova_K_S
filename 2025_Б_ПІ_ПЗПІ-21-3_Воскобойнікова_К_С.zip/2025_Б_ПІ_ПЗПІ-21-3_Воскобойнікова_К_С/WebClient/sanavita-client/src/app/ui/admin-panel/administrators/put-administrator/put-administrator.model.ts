export class EditingAdministratorValues {
  administratorId: number = 0
  name: string = ""
  middleName: string = ""
  lastName: string = ""
  email: string = ""
  phoneNumber: string = ""
}
