export class EditingManufacturerValues {
  manufacturerId: number = 0
  name: string = ""
}
