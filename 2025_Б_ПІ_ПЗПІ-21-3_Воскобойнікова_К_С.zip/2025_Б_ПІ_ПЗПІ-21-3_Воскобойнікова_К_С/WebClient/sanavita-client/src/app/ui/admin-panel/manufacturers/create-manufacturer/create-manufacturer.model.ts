export class ManufacturerValues {
  name: string = ""
}
