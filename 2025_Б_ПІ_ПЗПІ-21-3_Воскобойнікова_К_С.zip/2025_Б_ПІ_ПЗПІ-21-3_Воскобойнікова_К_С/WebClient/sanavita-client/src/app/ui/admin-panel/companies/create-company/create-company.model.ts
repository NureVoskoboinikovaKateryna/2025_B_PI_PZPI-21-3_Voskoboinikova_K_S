export class CompanyValues {
  companyName: string = ""
  address: string = ""
}
