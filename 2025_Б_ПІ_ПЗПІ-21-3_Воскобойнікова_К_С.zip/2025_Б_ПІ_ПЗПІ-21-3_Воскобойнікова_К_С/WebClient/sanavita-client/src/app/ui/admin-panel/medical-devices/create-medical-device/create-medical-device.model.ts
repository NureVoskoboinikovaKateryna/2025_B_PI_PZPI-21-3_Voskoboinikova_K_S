export class MedicalDeviceValues {
  productionYear: number = 2025
  manufacturerId: number = 0
  medicalDeviceTypeId: number = 0
}
