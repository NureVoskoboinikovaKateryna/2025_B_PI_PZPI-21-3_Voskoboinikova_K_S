export class EditingNotificationValues {
  notificationId: number = 0
  title: string = ""
  content: string = ""
  senderId: number = 0
  patientId: number = 0
  date: string = ""
}
