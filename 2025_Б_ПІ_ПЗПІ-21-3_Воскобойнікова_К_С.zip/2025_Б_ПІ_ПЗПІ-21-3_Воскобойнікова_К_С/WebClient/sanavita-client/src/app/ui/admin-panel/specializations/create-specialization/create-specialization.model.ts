export class SpecializationValues {
  name: string = ""
}
