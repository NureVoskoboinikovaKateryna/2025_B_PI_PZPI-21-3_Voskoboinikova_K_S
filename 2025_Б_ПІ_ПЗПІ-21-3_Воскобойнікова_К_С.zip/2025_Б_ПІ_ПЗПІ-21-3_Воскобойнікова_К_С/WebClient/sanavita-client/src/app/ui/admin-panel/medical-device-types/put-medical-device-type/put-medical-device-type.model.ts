export class EditingMedicalDeviceTypeValues {
  medicalDeviceTypeId: number = 0
  name: string = ""
}
