export class EditingSpecializationValues {
  specializationId: number = 0
  name: string = ""
}
