export class EditingCompanyValues {
  companyId: number = 0
  companyName: string = ""
  address: string = ""
}
