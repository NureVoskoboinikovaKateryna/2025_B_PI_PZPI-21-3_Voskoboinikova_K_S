export class EditingMedicalRecordValues {
  medicalRecordId: number = 0
  visitDate: string = ""
  diagnosis: string = ""
  medications: string = ""
  doctorId: number = 0
  patientId: number = 0
}
