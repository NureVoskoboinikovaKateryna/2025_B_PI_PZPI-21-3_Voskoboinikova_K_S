export class MedicalDeviceTypeValues {
  name: string = ""
}
