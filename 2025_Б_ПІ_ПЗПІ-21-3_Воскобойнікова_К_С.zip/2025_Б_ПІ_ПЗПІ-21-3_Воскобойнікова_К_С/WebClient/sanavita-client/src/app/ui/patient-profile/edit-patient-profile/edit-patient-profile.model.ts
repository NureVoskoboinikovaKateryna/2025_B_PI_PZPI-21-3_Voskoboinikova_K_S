export class EditingProfileValues {
  bTypeId: number = 0
  name: string = ""
  middleName: string = ""
  lastName: string = ""
  email: string = ""
  phoneNumber: string = ""
  address: string = ""
  age: number = 0
  height: number = 0
}
