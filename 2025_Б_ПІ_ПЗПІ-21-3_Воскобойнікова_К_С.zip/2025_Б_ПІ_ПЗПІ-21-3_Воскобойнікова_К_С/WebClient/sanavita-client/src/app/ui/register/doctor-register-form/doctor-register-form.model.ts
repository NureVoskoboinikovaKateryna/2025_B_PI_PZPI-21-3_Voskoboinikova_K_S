export class RegisterData {
  spezId: number = 0
  name: string = ""
  middleName: string = ""
  lastName: string = ""
  email: string = ""
  phoneNumber: string = ""
  password: string = ""
  confirmPassword: string = ""
}
