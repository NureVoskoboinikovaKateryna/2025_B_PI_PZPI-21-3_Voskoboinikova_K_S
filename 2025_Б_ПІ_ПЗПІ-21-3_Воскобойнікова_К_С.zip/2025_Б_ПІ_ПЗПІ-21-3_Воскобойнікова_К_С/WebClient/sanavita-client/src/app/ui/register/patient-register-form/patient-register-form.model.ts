export class RegisterData {
  bTypeId: number = 0
  companyId: number = 0
  name: string = ""
  middleName: string = ""
  lastName: string = ""
  email: string = ""
  phoneNumber: string = ""
  password: string = ""
  confirmPassword: string = ""
  gender: string = ""
  address: string = ""
  age: number = 0
  height: number = 0
}
