export class EditingProfileValues {
  name: string = ""
  middleName: string = ""
  lastName: string = ""
  email: string = ""
  phoneNumber: string = ""
  specializationId: number = 0
}
