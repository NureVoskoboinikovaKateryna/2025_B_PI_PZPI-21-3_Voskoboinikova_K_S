﻿namespace SanaVitaIoT.Models
{
    public class Patient
    {
    }
}
