﻿namespace sanavita.Dto
{
    public class DoctorUPDATE
    {
        public int SpecializationId { get; set; }
        public string Name { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
    }
}
