﻿namespace sanavita.Dto
{
    public class CompanyManagerDto
    {
        public int CompanyManagerId { get; set; }
    }
}
