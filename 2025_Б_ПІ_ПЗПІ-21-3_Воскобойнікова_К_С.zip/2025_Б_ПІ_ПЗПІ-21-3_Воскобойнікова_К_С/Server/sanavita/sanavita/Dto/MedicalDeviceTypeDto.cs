﻿namespace sanavita.Dto
{
    public class MedicalDeviceTypeDto
    {
        public int MedicalDeviceTypeId { get; set; }
        public string Name { get; set; }
    }
}
