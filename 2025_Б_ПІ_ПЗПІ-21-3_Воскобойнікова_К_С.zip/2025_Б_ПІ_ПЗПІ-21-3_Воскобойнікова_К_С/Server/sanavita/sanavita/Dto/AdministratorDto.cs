﻿namespace sanavita.Dto
{
    public class AdministratorDto
    {
        public int AdministratorId { get; set; }
    }
}
