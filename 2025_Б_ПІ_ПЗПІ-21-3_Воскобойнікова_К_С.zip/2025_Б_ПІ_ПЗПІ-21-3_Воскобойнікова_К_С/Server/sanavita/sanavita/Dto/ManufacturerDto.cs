﻿namespace sanavita.Dto
{
    public class ManufacturerDto
    {
        public int ManufacturerId { get; set; }
        public string Name { get; set; }
    }
}
