﻿namespace sanavita.Dto
{
    public class DoctorDto
    {
        public int DoctorId { get; set; }
        public int SpezId { get; set; }
    }
}
