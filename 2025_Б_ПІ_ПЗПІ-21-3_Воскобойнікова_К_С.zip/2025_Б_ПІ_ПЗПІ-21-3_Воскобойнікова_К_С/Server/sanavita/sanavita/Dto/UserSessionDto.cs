﻿namespace sanavita.Dto
{
    public record class UserSessionDto
    (
        string Id, string Name, string Email, string Role
    );
}
