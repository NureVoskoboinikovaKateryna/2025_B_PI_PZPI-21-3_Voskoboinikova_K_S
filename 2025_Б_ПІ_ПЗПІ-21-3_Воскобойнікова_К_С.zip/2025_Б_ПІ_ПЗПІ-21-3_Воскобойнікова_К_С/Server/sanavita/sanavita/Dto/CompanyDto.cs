﻿using sanavita.Models;

namespace sanavita.Dto
{
    public class CompanyDto
    {
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string Address { get; set; }
    }
}
