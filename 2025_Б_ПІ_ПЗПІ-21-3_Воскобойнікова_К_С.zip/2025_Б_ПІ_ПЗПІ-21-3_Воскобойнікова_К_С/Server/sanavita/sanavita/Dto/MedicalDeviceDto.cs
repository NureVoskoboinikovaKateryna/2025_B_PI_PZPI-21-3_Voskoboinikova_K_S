﻿namespace sanavita.Dto
{
    public class MedicalDeviceDto
    {
        public int MedicalDeviceId { get; set; }
        public int ProductionYear { get; set; }
        public int ManufacturerId { get; set; }
        public int MedicalDeviceTypeId { get; set; }
    }
}
