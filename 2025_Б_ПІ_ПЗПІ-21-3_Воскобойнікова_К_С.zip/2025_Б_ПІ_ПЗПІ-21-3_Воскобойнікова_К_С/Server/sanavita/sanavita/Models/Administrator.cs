﻿namespace sanavita.Models
{
    public class Administrator
    {
        public int AdministratorId { get; set; }
        public ApplicationUser ApplicationUser { get; set; }
    }
}
