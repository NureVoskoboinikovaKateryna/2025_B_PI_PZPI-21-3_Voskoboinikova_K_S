﻿namespace sanavita.Models
{
    public class Specialization
    {
        public int SpecializationId { get; set; }
        public string Name { get; set; }
    }
}
