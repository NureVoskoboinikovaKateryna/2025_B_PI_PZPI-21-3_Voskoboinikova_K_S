﻿namespace sanavita.Models
{
    public class BloodType
    {
        public int BloodTypeId { get; set; }
        public string TypeName { get; set; }
    }
}
